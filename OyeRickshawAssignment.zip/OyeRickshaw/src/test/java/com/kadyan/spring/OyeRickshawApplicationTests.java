package com.kadyan.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OyeRickshawApplicationTests {

	@Test
	void contextLoads() {
	}

}
